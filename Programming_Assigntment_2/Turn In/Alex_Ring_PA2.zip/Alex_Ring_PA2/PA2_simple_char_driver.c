#include<linux/init.h>
#include<linux/module.h>

#include<linux/fs.h>
#include<asm/uaccess.h>

#define BUFFER_SIZE 1024

static char device_buffer[BUFFER_SIZE];

int openCount = 0;
int closeCount = 0;
int placeholder = 0;

//Open, prints times opened
int device_open (struct inode *pinode, struct file *file_pointer)
{
        openCount++;
        printk(KERN_ALERT "Device opened:%d times", openCount);
        return 0;
}

//Close, prints times closed
int device_close (struct inode *pinode, struct file *file_pointer)
{
        closeCount++;
        printk(KERN_ALERT "Device closed:%d times\n", closeCount);
        return 0;
}


/*Device Reader
 *Takes the driver file as a pointer, the buffer from the user, the length of the read, and the offset
 */
ssize_t device_read (struct file *file_pointer, char __user *buffer, size_t length, loff_t *offset)
{
	int bytesRead;
	int bytesToRead = BUFFER_SIZE - *offset;
	int fromUser;
	//Check if at end of file
	if (bytesToRead == 0)
	{
		printk(KERN_ALERT "At the end of the file");
		return 0;
	}
	
	// Get bytes from the user using copy_to_user
	fromUser = copy_to_user(buffer, device_buffer + *offset, bytesToRead);
	//Subtract unread bytes
	bytesRead = bytesToRead - fromUser;
	printk(KERN_ALERT "Just read %d bytes\n", bytesRead);

	*offset += bytesRead;

	return bytesRead;
}

/*Device Writer
 *Takes the driver, file as a pointer, the buffer, the length of write, and offset
 */
ssize_t device_write (struct file *file_pointer, const char __user *buffer, size_t length, loff_t *offset)
{	
	int bytesToWrite;
	int bytesWritten;
	int bytesAvailable = BUFFER_SIZE - *offset - placeholder;
	int fromUser;

	// Make sure there is sufficient space
	if(bytesAvailable > length){
		bytesToWrite = length; 
	}
	else{
		bytesToWrite = bytesAvailable;
	}

	//Get bytes from user using copy_from_user
	fromUser = copy_from_user(device_buffer + *offset + placeholder, buffer, bytesToWrite);	
	bytesWritten = bytesToWrite - fromUser;
	
	// If no space left:
	if(bytesWritten == 0){
		printk(KERN_ALERT "The device is out of space.\n");
	}
	else{
		//Increment offset and placeholder
		*offset += bytesWritten;
		placeholder += bytesWritten;

		printk(KERN_ALERT "Writing %d bytes\n", bytesWritten);
	}
	return bytesWritten;
}


/* File structure based on the the structure from fs.h
 * .owner is the owner of the structure = this module
 * .read = read operation, .write = write opration, .open = open file, .realease = close file
 */
struct file_operations device_file_operations = {
	.owner   = THIS_MODULE,
	.read    = device_read,
	.write   = device_write,
	.open    = device_open,
	.release = device_close
};

/* 240 = Device number
 * simple_character_driver = name of the device
 * &device_file_operations = points to the struct above
 */
static int device_driver_init(void)
{
	printk(KERN_ALERT "---------------------------------------------------------------------------\n");
	printk(KERN_ALERT "Loading the driver\n");
	register_chrdev( 240, "simple_character_driver", &device_file_operations);
	return 0;
}

static void device_driver_exit(void)
{
	printk(KERN_ALERT "Unloading the driver\n");
	printk(KERN_ALERT "---------------------------------------------------------------------------\n");
	unregister_chrdev( 240, "simple_character_driver");
}


module_init(device_driver_init);
module_exit(device_driver_exit);
