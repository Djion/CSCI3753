#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024

int readDevice(){
	printf("\nData read from the device:\n");
	system("cat /dev/simple_character_device");
	printf("\n");
	menu();
}

int writeDevice(){
	printf("\nEnter data you want to write to the device:\n");
	
	char data[BUFFER_SIZE];
	
	if (fgets(data, BUFFER_SIZE, stdin) != NULL){
		char cmd[BUFFER_SIZE + 40]= {0x0};
		sprintf(cmd,"echo -n \"%s\" >> /dev/simple_character_device", data);
		system(cmd);
	}
	printf("\n");
	menu();	
}
int menu(){

	char inputBuffer[BUFFER_SIZE];

	printf("-/-/-/-/-/-/-/-/-/-/-/\n");	
	printf("       Menu\n");
	printf("-/-/-/-/-/-/-/-/-/-/-/\n");
	printf("r : read from the device\n");
	printf("w : write to the device\n");
	printf("e : exit\n");
	printf("\nPlease make a selection: ");

	if (fgets(inputBuffer, BUFFER_SIZE, stdin) != NULL)
	{
		if (inputBuffer[0] == 'r')
		{
			readDevice();
		}
		else if (inputBuffer[0] == 'w')
		{
			writeDevice();
		}
		else if (inputBuffer[0] == 'e')
		{
			exit(0);
		}
		else
		{
			printf("ERROR: Please select a valid option\n");
			menu();
		}
	}
	else
	{
		printf("ERROR: Selection must not be blank\n");
		menu();
	}
}

int main(){
	 menu();
}
